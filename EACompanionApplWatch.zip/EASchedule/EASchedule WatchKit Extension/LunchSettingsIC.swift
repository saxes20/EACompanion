//
//  LunchSettingsIC.swift
//  EASchedule
//
//  Created by Sameer on 11/11/15.
//  Copyright © 2016 Sameer. All rights reserved.
//

import WatchKit
import Foundation


class LunchSettingsIC: WKInterfaceController {

    @IBOutlet var dayPicker: WKInterfacePicker!
    @IBOutlet var clubPicker: WKInterfacePicker!
    
    var dayPickedTi: String?
    var clubPickedTi: String?
    
    var dayList: [String] = [""]
    var clubList: [String] = [""]
    
    let defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults()
    

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        
        dayList = ["Day 1", "Day 2", "Day 3", "Day 4", "Day 5", "Day 6", "Day 7", "Day 8", "Day 9", "Day 10", "Day 11", "Day 12", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]
        clubList = ["Nothing", "Sign Language","Astronomy","Black Union","Bella Voce", "Bishop's Bunker", "Book Club","Chess Club","China Club", "Classics", "Ch. Ensemble", "Chapel Council", "Commun. Conn.", "Creative Writing", "Dance Club", "Diversity Club", "Domino Club", "EA Drum Line", "EA Farms", "Eco Action","ESS","EA Sports", "EDM", "French Club", "Friends-Borders", "FBLA", "Game Theory", "Prism", "GRASP", "Harry Potter", "Improv", "Install-it", "Key Club", "Jazz Band", "Junto", "Math Club", "MathCounts", "Mock Trial", "Model UN", "Nutr./Food Awar.", "Origami", "Photography", "Problem Solvers", "Ski/Snowboard", "Sound of Sci.", "Spanish", "Stripes", "Tech Crew", "WhoDunnIt", "World Affairs", "Y. Democrats", "Y. Republicans", "Fre. Service", "Anime Club", "Tech Club"]
        
        let pickerItems: [WKPickerItem] = dayList.map {
            let pickerItem = WKPickerItem()
            pickerItem.title = $0
            return pickerItem
        }
        
        let clubItems: [WKPickerItem] = clubList.map {
            let pickerItem = WKPickerItem()
            pickerItem.title = $0
            return pickerItem
        }
        
        dayPicker.setItems(pickerItems)
        clubPicker.setItems(clubItems)
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBAction func dayPicked(value: Int) {
        dayPickedTi = dayList[value]
    }
    
    @IBAction func clubPicked(value: Int) {
        clubPickedTi = clubList[value]
    }
    
    @IBAction func submit() {
        //var aDictionary: [String: String]?
        
        if let dayPickedTitle = dayPickedTi {
            print("\(dayPickedTitle)")
        } else {
            dayPickedTi = "Day 1"
        }
        if let clubPickedTitle = clubPickedTi {
            print("\(clubPickedTitle)")
        } else {
            clubPickedTi = "Nothing"
        }
        
        /*
        print("I ran")
        aDictionary = ["0": dayPickedTi!, "1": clubPickedTi!]
        self.presentControllerWithName("LunchIC", context: aDictionary!)
        */
        
        self.dismissController()
        //DEFAULTS
        defaults.setObject(clubPickedTi, forKey: dayPickedTi!)
        
    }
    
    
    
    

}
