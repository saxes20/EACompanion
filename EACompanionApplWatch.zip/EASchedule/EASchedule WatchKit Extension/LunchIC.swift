//
//  LunchIC.swift
//  EASchedule
//
//  Created by Sameer on 11/11/15.
//  Copyright © 2016 Sameer. All rights reserved.
//

import WatchKit
import Foundation


class LunchIC: WKInterfaceController {

    @IBOutlet var clubLabel: WKInterfaceLabel!
    
    var dictionary: [String: String]?
    var dayString: String?
    var club: String?
    var day: Days?
    
    var dayClubDictionary: [String: String] = ["Day 1": "", "Day 2": "", "Day 3": "", "Day 4": "", "Day 5": "", "Day 6": "", "Day 7": "", "Day 8": "", "Day 9": "", "Day 10": "", "Day 11": "", "Day 12": ""]
    
    override func awakeWithContext(context: AnyObject?) {
        super.awakeWithContext(context)
        if let context = context {
            let dayString = context as? String as String?
            let defaults = NSUserDefaults.standardUserDefaults()
            if let day = dayString {
                if let club = defaults.objectForKey(day) {
                    clubLabel.setText("\(club)")
                    dayClubDictionary[dayString!] = club as? String
                }
            } else {
                clubLabel.setText("Nothing")
            }
        } else {
            clubLabel.setText("Nothing")
        }
        /*
        dictionary = context as! [String: String]?
        if let dictionary = dictionary {
            print("\(dictionary["0"]) and \(dictionary["1"])")
            club = dictionary["1"]
            clubLabel.setText("\(club)")
            
        } */
        // Configure interface objects here.
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    
}
