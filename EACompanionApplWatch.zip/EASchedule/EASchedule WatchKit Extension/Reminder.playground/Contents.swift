//: Playground - noun: a place where people can play

import Cocoa

//HOW TO CONVERT TO UPPER SCHOOL
/*
1. Change Upper School bool in GlanceController
2. Change Upper School bool in InterfaceController





*/

