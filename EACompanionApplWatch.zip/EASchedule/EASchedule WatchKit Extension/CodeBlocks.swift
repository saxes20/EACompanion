//
//  CodeBlocks.swift
//  EASchedule
//
//  Created by Sameer on 9/30/15.
//  Copyright © 2016 Sameer. All rights reserved.
//

import Foundation
import UIKit
import WatchKit

struct CodeBlocks {
    //func getTime() -> NSDate)
    
}