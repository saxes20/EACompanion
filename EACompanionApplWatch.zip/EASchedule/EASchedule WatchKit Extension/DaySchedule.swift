//
//  DaySchedule.swift
//  EASchedule
//
//  Created by Sameer on 9/29/15.
//  Copyright © 2016 Sameer. All rights reserved.
//

import Foundation

enum Days {
    case day1
    case day2
    case day3
    case day4
    case day5
    case day6
    case day7
    case day8
    case day9
    case day10
    case day11
    case day12
    case eaHav
    case winterDay
    case lastDay
}

struct DaySchedule {
    var day: Days
    var schedule: [String]
    var nameOfDay: String
    
    init(day: Days) {
        self.day = day
        switch day {
            case .day1:
                schedule = ["A", "F", "Office Hours", "E", "Z", "Lunch", "B", "D", "C"]
                nameOfDay = "Day 1"
            case .day2:
                schedule = ["B", "A", "Chapel", "F", "Z", "Lunch", "C", "E", "D"]
                nameOfDay = "Day 2"
            case .day3:
                schedule = ["C", "B", "Advisory", "A", "Z", "Lunch", "D", "F", "E"]
                nameOfDay = "Day 3"
            case .day4:
                schedule = ["D", "C", "Chapel", "B", "Z", "Lunch", "E", "A", "F"]
                nameOfDay = "Day 4"
            case .day5:
                schedule = ["E", "D", "Office Hours", "C", "Z", "Lunch", "F", "B", "A"]
                nameOfDay = "Day 5"
            case .day6:
                schedule = ["F", "E", "Chapel", "A", "Z", "Lunch", "D", "C", "B"]
                nameOfDay = "Day 4"
            case .day7:
                schedule = ["A", "F", "Office Hours", "E", "Z", "Lunch", "B", "D", "C"]
                nameOfDay = "Day 7"
            case .day8:
                schedule = ["B", "A", "Chapel", "F", "Z", "Lunch", "C", "E", "D"]
                nameOfDay = "Day 8"
            case .day9:
                schedule = ["C", "B", "Advisory", "A", "Z", "Lunch", "D", "F", "E"]
                nameOfDay = "Day 9"
            case .day10:
                schedule = ["D", "C", "Chapel", "B", "Z", "Lunch", "E", "A", "F"]
                nameOfDay = "Day 10"
            case .day11:
                schedule = ["E", "D", "Office Hours", "C", "Z", "Lunch", "F", "B", "A"]
                nameOfDay = "Day 11"
            case .day12:
                schedule = ["A", "F", "Chapel", "B", "Z", "Lunch", "D", "C", "E"]
                nameOfDay = "Day 12"
            case .eaHav:
                schedule = ["C", "Chapel", "Pep Rally", "Lunch", "Games @ AIS"]
                nameOfDay = "EA/HAV/AIS"
            case .winterDay:
                schedule = ["F", "E", "A", "Z", "Chapel"]
                nameOfDay = "Day 6"
            case .lastDay:
                schedule = ["Final Exam", "Advisory", "Chapel", "US Picnic", "Assembly"]
                nameOfDay = "Last Day"
            
        }
    }
}
