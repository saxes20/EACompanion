//
//  InterfaceController.swift
//  EASchedule WatchKit Extension
//
//  Created by Sameer on 9/29/15.
//  Copyright © 2016 Sameer. All rights reserved.
//

import WatchKit
import Foundation



class InterfaceController: WKInterfaceController {

    @IBOutlet var dayLabel: WKInterfaceLabel!
    @IBOutlet var blockLabel: WKInterfaceLabel!
    @IBOutlet var clubLabel: WKInterfaceLabel!
    
    var isthereDay: Bool = false
    var dayTuple: (Days, NSAttributedString)?
    var dayString: String?
    var dayOfWeek: String = "Sunday"
    var indexTime = 0
    
    var blockToggle = true
    var dayToggle = false
    
    var noschool = false
    
    var specialDay = false
    var havDay = false
    var winterDay = false
    var jterm = false
    var readingDay = false
    var exams = false
    var lastDay = false
    var avDay = false
    
    let upperschool = true
    
    var none = true
    
    var dayClubDictionary: [String: String] = ["Day 1": "", "Day 2": "", "Day 3": "", "Day 4": "", "Day 5": "", "Day 6": "", "Day 7": "", "Day 8": "", "Day 9": "", "Day 10": "", "Day 11": "", "Day 12": "", "Monday": "", "Tuesday": "", "Wednesday": "", "Thursday": "", "Friday": ""]

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        //Figuring out the currentHour and currentDay
        let date = NSDate()
        let calendar = NSCalendar.currentCalendar()
        let componentsHour = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Hour), fromDate: date)
        let componentsMinute = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Minute), fromDate: date)
        let componentsDay = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Day), fromDate: date)
        let componentsMonth = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Month), fromDate: date)
        let componentsYear = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Year), fromDate: date)
        let hour = componentsHour.hour
        let minute = componentsMinute.minute
        let day = componentsDay.day
        let month = componentsMonth.month
        let year = componentsYear.year
        
        let dayInt = getDayOfWeek()
        switch dayInt {
            case 2:
                dayOfWeek = "Monday"
                break
            case 3:
                dayOfWeek = "Tuesday"
                break
            case 4:
                dayOfWeek = "Wednesday"
                break
            case 5:
                dayOfWeek = "Thursday"
                break
            case 6:
                dayOfWeek = "Friday"
                break
            default:
                dayOfWeek = "Sunday"
        }
        
        var dateAsString = "\(month)-\(day)-\(year)"
        
        checkSchedule(dateAsString, hour: hour, minute: minute)
        
        
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func checkSchedule(dateAsString: String, hour: Int, minute: Int) {
        if let plistPath = NSBundle.mainBundle().pathForResource("DaySchedule", ofType: "plist")  {
            let dayScheduleDict = NSDictionary(contentsOfFile: plistPath)
            print(dateAsString)
            //dayScheduleDict!["9-9-2016"] as? String
            if let day = dayScheduleDict![dateAsString] as? String {
                print(day)
                dayString = day
                dayTuple = findDay(day)
                if dateAsString == "9-23-2016" {
                    avDay = true
                }
                if !upperschool {
                    let scheduleOfDay = DaySchedule(day: dayTuple!.0)
                    findBlock(scheduleOfDay, hour: hour, minute: minute)
                } else {
                    let scheduleOfDay = DayScheduleUS(day: dayTuple!.0)
                    findBlockUS(scheduleOfDay, hour: hour, minute: minute)
               }
                dayLabel.setAttributedText(dayTuple!.1)
                noschool = false
                
                if dateAsString == "10-19-2016" {
                    if upperschool {
                        let atrText = NSAttributedString(string: "PSAT/Irr. Day", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(14, weight: 0)])
                        blockLabel.setAttributedText(atrText)
                        specialDay = true
                    }
                }
                
                if dateAsString == "10-28-2016" {
                    noschool = true
                    let atrText = NSAttributedString(string: "No School", attributes: [NSFontAttributeName: UIFont.systemFontOfSize( 25, weight: 0.5)])
                    dayLabel.setAttributedText(atrText)
                    blockLabel.setText("N/A")
                    clubLabel.setText("Nothing")
                }
               
                if dateAsString == "3-10-2017" {
                    noschool = true
                    let atrText = NSAttributedString(string: "No School", attributes: [NSFontAttributeName: UIFont.systemFontOfSize( 25, weight: 0.5)])
                    dayLabel.setAttributedText(atrText)
                    blockLabel.setText("N/A")
                    clubLabel.setText("Nothing")
                }

                if dateAsString == "1-16-2017" {
                    noschool = true
                    let atrText = NSAttributedString(string: "No School", attributes: [NSFontAttributeName: UIFont.systemFontOfSize( 25, weight: 0.5)])
                    dayLabel.setAttributedText(atrText)
                    blockLabel.setText("N/A")
                    clubLabel.setText("Nothing")
                }
                
                if dateAsString == "2-17-2017" {
                    noschool = true
                    let atrText = NSAttributedString(string: "No School", attributes: [NSFontAttributeName: UIFont.systemFontOfSize( 25, weight: 0.5)])
                    dayLabel.setAttributedText(atrText)
                    blockLabel.setText("N/A")
                    clubLabel.setText("Nothing")
                }
                
                if dateAsString == "2-20-2017" {
                    noschool = true
                    let atrText = NSAttributedString(string: "No School", attributes: [NSFontAttributeName: UIFont.systemFontOfSize( 25, weight: 0.5)])
                    dayLabel.setAttributedText(atrText)
                    blockLabel.setText("N/A")
                    clubLabel.setText("Nothing")
                }


                if dateAsString == "11-11-2016" {
                    let atrText = NSAttributedString(string: "EA/HAV/AIS", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 0.5)])
                    dayLabel.setAttributedText(atrText)
                    havDay = true
                    //findBlock adjust
                    let scheduleOfDay = DaySchedule(day: Days.eaHav)
                    findEAHAVBLock(scheduleOfDay, hour: hour, minute: minute)
                    //previous/next adjust
                }
                
                if dateAsString == "12-16-2016" {
                    winterDay = true
                    let scheduleOfDay = DaySchedule(day: Days.winterDay)
                    findWinterDay(scheduleOfDay, hour: hour, minute: minute)
                    
                }
                
                //TEST JTERM
                let first = String(dateAsString[dateAsString.startIndex.advancedBy(0)])
                let dash = String(dateAsString[dateAsString.startIndex.advancedBy(1)])
                //print(dateAsString[index])
                if first == "1" && dash == "-" {
                    let second = String(dateAsString[dateAsString.startIndex.advancedBy(2)])
                    let integer = Int(second)
                    //print(integer)
                    if integer! >= 3 && integer! <= 13 {
                        if upperschool {
                            jterm = true
                            print("JTERM")
                            blockLabel.setText("JTerm")
                            dayLabel.setText("JTerm")
                        }
                    } else {
                        var array: [Character] = []
                        for i in 2...3 {
                            let add = String(dateAsString[dateAsString.startIndex.advancedBy(i)])
                            array.append(Character(add))
                        }
                        let string = String(array)
                        if let integer = Int(string) {
                            if integer >= 3 && integer <= 13 {
                                if upperschool {
                                    jterm = true
                                    print("JTERM")
                                    blockLabel.setText("JTerm")
                                    dayLabel.setText("JTerm")
                                }
                            }
                        }
                    }
                }
                
                if dateAsString == "5-25-2017" {
                    if upperschool {
                        let atrText = NSAttributedString(string: "Reading Day", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(22, weight: 0.5)])
                        dayLabel.setAttributedText(atrText)
                        blockLabel.setText("Reading Day")
                        readingDay = true
                    }
                }
                
                if dateAsString == "5-26-2017" {
                    if upperschool {
                        dayLabel.setText("Exams")
                        blockLabel.setText("Finals")
                        exams = true
                    } else {
                        noschool = true
                        let atrText = NSAttributedString(string: "No School", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(25, weight: 0.5)])
                        dayLabel.setAttributedText(atrText)
                        blockLabel.setText("N/A")
                        clubLabel.setText("Nothing")
                    }
                }
                
                if dateAsString == "5-30-2017" || dateAsString == "5-31-2017" {
                    dayLabel.setText("Exams")
                    blockLabel.setText("Finals")
                    exams = true
                }
                
                if dateAsString == "6-1-2017" {
                    dayLabel.setText("Exams")
                    blockLabel.setText("Finals")
                    exams = true
                }
                
                if dateAsString == "6-2-2017" {
                    lastDay = true
                    dayLabel.setText("Last Day")
                    let scheduleOfDay = DaySchedule(day: Days.lastDay)
                    findLastDay(scheduleOfDay, hour: hour, minute: minute)
                }
                
                let defaults = NSUserDefaults.standardUserDefaults()
                if let club = defaults.objectForKey(day) {
                    if !specialDay && !havDay && !jterm && !readingDay && !exams && !lastDay {
                        clubLabel.setText("\(club)")
                        let len = (club as! String).characters.count
                        print("Len is \(len)")
                        let over = len - 12
                        var size = 16
                        if over <= 0 {
                            size = 16
                        }
                        else {
                            size = 16 - over
                        }
                        print("Over is \(over)")
                        /*
                        if club as! String == "Chapel Council" {
                            let atrText = NSAttributedString(string: "Chapel Council", attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 14, weight: 0)])
                            clubLabel.setAttributedText(atrText)
                        }
                        else if club as! String == "Student Council" {
                            let atrText = NSAttributedString(string: "Student Council", attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 13, weight: 0)])
                            clubLabel.setAttributedText(atrText)
                        }
                        else if club as! String == "Diversity Council" || club as! String == "Chamber Ensemble" {
                            let atrText = NSAttributedString(string: "\(club)", attributes: [NSFontAttributeName: UIFont.systemFont(ofSize: 12, weight: 0)])
                            clubLabel.setAttributedText(atrText)
                        } */
                        print(size)
                        let atrText = NSAttributedString(string: "\(club)", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(CGFloat(size), weight: 0)])
                        clubLabel.setAttributedText(atrText)
                        dayClubDictionary[dayString!] = club as? String
                    }
                }
                if let club = defaults.objectForKey(dayOfWeek) {
                    if !specialDay && !havDay && !jterm && !readingDay && !exams && !lastDay{
                        if (club as! String) == "Nothing" {
                            print("None")
                            var club1 = defaults.objectForKey(day)
                            print(club1)
                            let len = (club1 as! String).characters.count
                            print("Len is \(len)")
                            let over = len - 12
                            var size = 16
                            if over <= 0 {
                                size = 16
                            }
                            else {
                                size = 16 - over
                            }
                            print("Over is \(over)")
                            print(size)
                            if let clu = club1 {
                                club1 = clu
                            } else {
                                club1 = "Nothing"
                            }
                            let atrText = NSAttributedString(string: "\(club1!)", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(CGFloat(size), weight: 0)])
                            clubLabel.setAttributedText(atrText)
                            dayClubDictionary[dayOfWeek] = club1 as? String

                        } else {
                            clubLabel.setText("\(club)")
                            let len = (club as! String).characters.count
                            print("Len is \(len)")
                            let over = len - 12
                            var size = 16
                            if over <= 0 {
                                size = 16
                            }
                            else {
                                size = 16 - over
                            }
                            print("Over is \(over)")
                            print(size)
                            let atrText = NSAttributedString(string: "\(club)", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(CGFloat(size), weight: 0)])
                            clubLabel.setAttributedText(atrText)
                            dayClubDictionary[dayOfWeek] = club as? String
                        }
                    }
                }
                
            } else {
                noschool = true
                let atrText = NSAttributedString(string: "No School", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(20, weight: 0.5)])
                dayLabel.setAttributedText(atrText)
                blockLabel.setText("N/A")
                clubLabel.setText("Nothing")
            }
            
        }
        
    }
    
    
    @IBAction func next() {
        if !noschool && !specialDay && !havDay && !winterDay && !jterm && !readingDay && !exams && !lastDay {
            indexTime = indexTime + 1
            
            if indexTime > 8 {
                indexTime = 8
            }
            
            if !upperschool {
                switch indexTime {
                    case 0:
                        //messageLabel.setText("First Class:")
                        blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                    case 1:
                        //messageLabel.setText("Current Class:")
                        blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                    case 2:
                        //messageLabel.setText("Activity:")
                        blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0)))")
                    case 3:
                        //messageLabel.setText("Current Class:")
                        blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                    case 4:
                        //messageLabel.setText("Current Class:")
                        blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                    case 5:
                        //messageLabel.setText("Activity:")
                        blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0)))")
                    case 6:
                        //messageLabel.setText("Current Class:")
                        blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                    case 7:
                        //messageLabel.setText("Current Class:")
                        if !avDay {
                            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                        } else {
                            blockLabel.setText("A/V Day")
                        }
                    case 8:
                        if !avDay {
                            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                        } else {
                            blockLabel.setText("A/V Day")
                        }
                    default:
                        if !avDay {
                            //messageLabel.setText("Last Class:")
                            blockLabel.setText("\(getTextForLabel(8, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                        } else {
                            blockLabel.setText("A/V Day")
                        }
                        break
                }
            }
            
            else if upperschool {
                switch indexTime {
                case 0:
                    //messageLabel.setText("First Class:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                case 1:
                    //messageLabel.setText("Current Class:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                case 2:
                    //messageLabel.setText("Activity:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0)))")
                case 3:
                    //messageLabel.setText("Current Class:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                case 4:
                    //messageLabel.setText("Current Class:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                case 5:
                    //messageLabel.setText("Activity:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                case 6:
                    //messageLabel.setText("Current Class:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0)))")
                case 7:
                    //messageLabel.setText("Current Class:")
                    if !avDay {
                        blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                    } else {
                        blockLabel.setText("A/V Day")
                    }
                case 8:
                    //messageLabel.setText("Last Class:")
                    if !avDay {
                        blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                    } else {
                        blockLabel.setText("A/V Day")
                    }
                default:
                    if !avDay {
                        //messageLabel.setText("Last Class:")
                        blockLabel.setText("\(getTextForLabelUS(8, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                    } else {
                        blockLabel.setText("A/V Day")
                    }
                    break
                }
            }
        }
        else if havDay {
            indexTime = indexTime + 1
            
            if indexTime > 4 {
                indexTime = 4
            }
            
            switch indexTime {
            case 0:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.eaHav))) Block")
            case 1:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.eaHav)))")
            case 2:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.eaHav)))")
            case 3:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.eaHav)))")
            case 4:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.eaHav)))")
            default:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.eaHav)))")
                break
            }
        }
        else if winterDay {
            indexTime = indexTime + 1
            
            if indexTime > 4 {
                indexTime = 4
            }
            
            switch indexTime {
            case 0:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.winterDay))) Block")
            case 1:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.winterDay))) Block")
            case 2:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.winterDay))) Block")
            case 3:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.winterDay))) Block")
            case 4:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.winterDay)))")
            default:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.winterDay)))")
                break
            }
        }
        else if lastDay {
            indexTime = indexTime + 1
            
            if indexTime > 4 {
                indexTime = 4
            }
            
            switch indexTime {
            case 0:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.lastDay)))")
            case 1:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.lastDay)))")
            case 2:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.lastDay)))")
            case 3:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.lastDay)))")
            case 4:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.lastDay)))")
            default:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.lastDay)))")
                break
            }
            
        }
    }
    
    @IBAction func previous() {
        if !noschool && !specialDay && !havDay && !winterDay && !jterm && !readingDay && !exams && !lastDay {
            indexTime = indexTime - 1
            if indexTime < 0 {
                indexTime = 0
            }
            if !upperschool {
                switch indexTime {
                case 0:
                    //messageLabel.setText("First Class:")
                    blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                case 1:
                    //messageLabel.setText("Current Class:")
                    blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                case 2:
                    //messageLabel.setText("Activity:")
                    blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0)))")
                case 3:
                    //messageLabel.setText("Current Class:")
                    blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                case 4:
                    //messageLabel.setText("Current Class:")
                    blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                case 5:
                    //messageLabel.setText("Activity:")
                    blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0)))")
                case 6:
                    //messageLabel.setText("Current Class:")
                    blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                case 7:
                    //messageLabel.setText("Current Class:")
                    if !avDay {
                        blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                    } else {
                        blockLabel.setText("A/V Day")
                    }
                case 8:
                    if !avDay {
                        blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                    } else {
                        blockLabel.setText("A/V Day")
                    }
                default:
                    if !avDay {
                        //messageLabel.setText("Last Class:")
                        blockLabel.setText("\(getTextForLabel(8, dayschedule: DaySchedule(day: dayTuple!.0))) Block")
                    } else {
                        blockLabel.setText("A/V Day")
                    }
                    break
                }
            }
                
            else if upperschool {
                switch indexTime {
                case 0:
                    //messageLabel.setText("First Class:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                case 1:
                    //messageLabel.setText("Current Class:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                case 2:
                    //messageLabel.setText("Activity:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0)))")
                case 3:
                    //messageLabel.setText("Current Class:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                case 4:
                    //messageLabel.setText("Current Class:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                case 5:
                    //messageLabel.setText("Activity:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                case 6:
                    //messageLabel.setText("Current Class:")
                    blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0)))")
                case 7:
                    //messageLabel.setText("Current Class:")
                    if !avDay {
                        blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                    } else {
                        blockLabel.setText("A/V Day")
                    }
                case 8:
                    //messageLabel.setText("Last Class:")
                    if !avDay {
                        blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                    } else {
                        blockLabel.setText("A/V Day")
                    }
                default:
                    //messageLabel.setText("Last Class:")
                    if !avDay {
                        blockLabel.setText("\(getTextForLabelUS(8, dayschedule: DayScheduleUS(day: dayTuple!.0))) Block")
                    } else {
                        blockLabel.setText("A/V Day")
                    }
                    break
                }
            }
        }
        else if havDay {
            
            indexTime = indexTime - 1
            if indexTime < 0 {
                indexTime = 0
            }
            
            switch indexTime {
            case 0:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.eaHav))) Block")
            case 1:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.eaHav)))")
            case 2:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.eaHav)))")
            case 3:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.eaHav)))")
            case 4:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.eaHav)))")
            default:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.eaHav)))")
                break
            }
        }
        else if winterDay {
            
            indexTime = indexTime - 1
            
            if indexTime < 0 {
                indexTime = 0
            }
            
            switch indexTime {
            case 0:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.winterDay))) Block")
            case 1:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.winterDay))) Block")
            case 2:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.winterDay))) Block")
            case 3:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.winterDay))) Block")
            case 4:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.winterDay)))")
            default:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.winterDay)))")
                break
            }
        }
        else if lastDay {
            
            indexTime = indexTime - 1
            
            if indexTime < 0 {
                indexTime = 0
            }
            
            switch indexTime {
            case 0:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.lastDay)))")
            case 1:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.lastDay)))")
            case 2:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.lastDay)))")
            case 3:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.lastDay)))")
            case 4:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.lastDay)))")
            default:
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: DaySchedule(day: Days.lastDay)))")
                break
            }
        }
    }
    
    
    
    @IBAction func lunch() {
        //self.presentControllerWithName("LunchIC", context: dayString)
    }
    
    func getTextForLabel(indexnumber: Int, dayschedule: DaySchedule) -> String {
        print("\(dayschedule.schedule[indexnumber])")
        return dayschedule.schedule[indexnumber]
        
    }
    
    
    func getTextForLabelUS(indexnumber: Int, dayschedule: DayScheduleUS) -> String {
        print("\(dayschedule.schedule[indexnumber])")
        return dayschedule.schedule[indexnumber]
        
    } 
    
    func findDay(day: String) -> (Days, NSAttributedString) {
        switch day {
            case "Day 1":
                let atrText = NSAttributedString(string: "DAY 1", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(25, weight: 0.5)])
                return (Days.day1, atrText)
            case "Day 2":
                let atrText = NSAttributedString(string: "DAY 2", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(25, weight: 0.5)])
                return (Days.day2, atrText)
            case "Day 3":
                let atrText = NSAttributedString(string: "DAY 3", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(25, weight: 0.5)])
                return (Days.day3, atrText)
            case "Day 4":
                let atrText = NSAttributedString(string: "DAY 4", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(25, weight: 0.5)])
                return (Days.day4, atrText)
            case "Day 5":
                 let atrText = NSAttributedString(string: "DAY 5", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(25, weight: 0.5)])
                return (Days.day5, atrText)
            case "Day 6":
                let atrText = NSAttributedString(string: "DAY 6", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(25, weight: 0.5)])
                return (Days.day6, atrText)
            case "Day 7":
                let atrText = NSAttributedString(string: "DAY 7", attributes: [NSFontAttributeName:UIFont.systemFontOfSize(25, weight: 0.5)])
                return (Days.day7, atrText)
            case "Day 8":
                let atrText = NSAttributedString(string: "DAY 8", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(25, weight: 0.5)])
                return (Days.day8, atrText)
            case "Day 9":
                let atrText = NSAttributedString(string: "DAY 9", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(25, weight: 0.5)])
                return (Days.day9, atrText)
            case "Day 10":
                let atrText = NSAttributedString(string: "DAY 10", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(25, weight: 0.5)])
                return (Days.day10, atrText)
            case "Day 11":
                let atrText = NSAttributedString(string: "DAY 11", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(25, weight: 0.5)])
                return (Days.day11, atrText)
            default:
                let atrText = NSAttributedString(string: "DAY 12", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(25, weight: 0.5)])
                return (Days.day12, atrText)
        }

    }
    
    func findBlock(scheduleOfDay: DaySchedule, hour: Int, minute: Int) {
        //Return the message and block based on current hour and minute
        
        print(hour)
        print(minute)
        
        if hour < 8 || (hour == 8 && minute < 10) {
            indexTime = 0
            //messageLabel.setText("First Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if (hour == 8 && minute >= 10) && (hour == 8 && minute <= 50) {
            indexTime = 0
            //messageLabel.setText("First Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 8 && minute > 50 {
            indexTime = 1
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if (hour == 9 && minute >= 0) && (hour == 9 && minute <= 35) {
            indexTime = 1
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 9 && minute > 35 {
            indexTime = 2
            //messageLabel.setText("Activity:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 && minute <= 20 {
            indexTime = 2
            //messageLabel.setText("Activity:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 && minute > 20 {
            indexTime = 3
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 11 && minute <= 5 {
            indexTime = 3
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if (hour == 11 && minute > 5) && (hour == 11 && minute <= 50){
            indexTime = 4
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 11 && minute > 50 {
            indexTime = 5
            //messageLabel.setText("Activity:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 12 && minute < 30 {
            indexTime = 5
            //messageLabel.setText("Activity:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 12 && minute >= 30 {
            indexTime = 6
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 13 && minute < 15 {
            indexTime = 6
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 13 && minute >= 15 {
            if !avDay {
                indexTime = 7
                //messageLabel.setText("Current Class")
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
            } else {
                blockLabel.setText("A/V Day")
            }
        }
        else if hour == 14 && minute >= 0 {
            if !avDay {
                indexTime = 8
                //messageLabel.setText("Final Class")
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
            } else {
                blockLabel.setText("A/V Day")
            }
        } else {
            if !avDay {
                indexTime = 8
                //messageLabel.setText("Last Class")
                blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
            } else {
                blockLabel.setText("A/V Day")
            }
        }
    }
    
    
    func findBlockUS(scheduleOfDay: DayScheduleUS, hour: Int, minute: Int) {
        //Return the message and block based on current hour and minute
        
        print(hour)
        print(minute)
        
        if hour < 8 || (hour == 8 && minute < 10) {
            indexTime = 0
            //messageLabel.setText("First Class:")
            blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if (hour == 8 && minute >= 10) && (hour == 8 && minute <= 50) {
            indexTime = 0
            //messageLabel.setText("First Class:")
            blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 8 && minute > 50 {
            indexTime = 1
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if (hour == 9 && minute >= 0) && (hour == 9 && minute <= 35) {
            indexTime = 1
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 9 && minute > 35 {
            indexTime = 2
            //messageLabel.setText("Activity:")
            blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 && minute <= 10 {
            indexTime = 2
            //messageLabel.setText("Activity:")
            blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 && minute > 10 {
            indexTime = 3
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if (hour == 11 && minute >= 0) && (hour == 11 && minute <= 50) {
            indexTime = 4
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 11 && minute > 50 {
            indexTime = 5
            //messageLabel.setText("Activity:")
            blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 12 && minute <= 40 {
            indexTime = 5
            //messageLabel.setText("Activity:")
            blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 12 && minute > 40 {
            indexTime = 6
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 13 && minute <= 15 {
            indexTime = 6
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 13 && minute >= 15 {
            if !avDay {
                indexTime = 7
                //messageLabel.setText("Current Class")
                blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
            } else {
                blockLabel.setText("A/V Day")
            }
        }
        else if hour == 14 && minute >= 0 {
            if !avDay {
                indexTime = 8
                //messageLabel.setText("Current Class")
                blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
            } else {
                blockLabel.setText("A/V Day")
            }
        } else {
            if !avDay {
                indexTime = 8
                //messageLabel.setText("Current Class")
                blockLabel.setText("\(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
            } else {
                blockLabel.setText("A/V Day")
            }
        }
    }
    
    func findEAHAVBLock(scheduleOfDay: DaySchedule, hour: Int, minute: Int) {
        if hour <= 8 {
            indexTime = 0
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 9 {
            indexTime = 1
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 {
            indexTime = 2
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 11 && minute >= 30 {
            indexTime = 3
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else {
            indexTime = 4
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
    }
    
    func findWinterDay(scheduleOfDay: DaySchedule, hour: Int, minute: Int) {
        if hour <= 8 {
            indexTime = 0
            //messageLabel.setText("First Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 8 && minute >= 10 {
            indexTime = 0
            //messageLabel.setText("First Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 8 && minute >= 50 {
            indexTime = 1
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 9 && minute >= 0 {
            indexTime = 1
            //messageLabel.setText("Current Class:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 9 && minute >= 45 {
            indexTime = 2
            //messageLabel.setText("Activity:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 10 && minute <= 20 {
            indexTime = 2
            //messageLabel.setText("Activity:")
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 10 && minute > 20 {
            indexTime = 3
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 10 && minute >= 55 {
            indexTime = 4
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else {
            indexTime = 4
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }

    }
    
    func findLastDay(scheduleOfDay: DaySchedule, hour: Int, minute: Int) {
        if hour < 10 {
            indexTime = 0
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 && minute <= 55 {
            indexTime = 1
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 && minute > 55 {
            indexTime = 2
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 11 {
            indexTime = 2
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 12 {
            indexTime = 3
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 1 && minute <= 30 {
            indexTime = 3
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else {
            indexTime = 4
            blockLabel.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
    }
    
    func getDayOfWeek()->Int {
        let todayDate = NSDate()
        let myCalendar = NSCalendar(calendarIdentifier: NSCalendarIdentifierGregorian)!
        let myComponents = myCalendar.components(.Weekday, fromDate: todayDate)
        let weekDay = myComponents.weekday
        return weekDay
    }


}
