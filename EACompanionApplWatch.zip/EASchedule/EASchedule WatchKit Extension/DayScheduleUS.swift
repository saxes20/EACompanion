//
//  DayScheduleUS.swift
//  EASchedule
//
//  Created by Sameer on 2/7/16.
//  Copyright © 2016 Sameer. All rights reserved.
//

import Foundation

struct DayScheduleUS {
    var day: Days
    var schedule: [String]
    var nameOfDay: String
    
    init(day: Days) {
        self.day = day
        switch day {
        case .day1:
            schedule = ["A", "F", "Chapel", "E", "Z", "B", "Lunch", "Dx", "C"]
            nameOfDay = "Day 1"
        case .day2:
            schedule = ["B", "A", "Advisory", "F", "Z", "C", "Lunch", "Ex", "D"]
            nameOfDay = "Day 2"
        case .day3:
            schedule = ["C", "B", "Chapel", "A", "Z", "D", "Lunch", "Fx", "E"]
            nameOfDay = "Day 3"
        case .day4:
            schedule = ["D", "C", "Activity", "B", "Z", "E", "Lunch", "Ax", "F"]
            nameOfDay = "Day 4"
        case .day5:
            schedule = ["E", "D", "Chapel", "C", "Z", "F", "Lunch", "Bx", "A"]
            nameOfDay = "Day 5"
        case .day6:
            schedule = ["F", "E", "A&E Lab Break", "A", "Z", "D", "Lunch", "Cx", "B"]
            nameOfDay = "Day 4"
        case .day7:
            schedule = ["A", "F", "Chapel", "E", "Z", "B", "Lunch", "Dx", "C"]
            nameOfDay = "Day 7"
        case .day8:
            schedule = ["B", "A", "Activity", "F", "Z", "C", "Lunch", "Ex", "D"]
            nameOfDay = "Day 8"
        case .day9:
            schedule = ["C", "B", "Chapel", "A", "Z", "D", "Lunch", "Fx", "E"]
            nameOfDay = "Day 9"
        case .day10:
            schedule = ["D", "C", "Activity", "B", "Z", "E", "Lunch", "Ax", "F"]
            nameOfDay = "Day 10"
        case .day11:
            schedule = ["E", "D", "Chapel", "C", "Z", "F", "Lunch", "Bx", "A"]
            nameOfDay = "Day 11"
        case .day12:
            schedule = ["A", "F", "B&F Lab Break", "B", "Z", "D", "Lunch", "Cx", "E"]
            nameOfDay = "Day 12"
        case .eaHav:
            schedule = ["C", "Chapel", "Pep Rally", "Lunch", "Games @ AIS"]
            nameOfDay = "EA/HAV/AIS"
        case .winterDay:
            schedule = ["F", "E", "A", "Z", "Chapel"]
            nameOfDay = "Day 6"
        case .lastDay:
            schedule = ["Final Exam", "Advisory", "Chapel", "US Picnic"]
            nameOfDay = "Last Day"
            
        }
    }

}


