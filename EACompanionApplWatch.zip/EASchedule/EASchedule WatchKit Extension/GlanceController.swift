//
//  GlanceController.swift
//  EASchedule WatchKit Extension
//
//  Created by Sameer on 9/29/15.
//  Copyright © 2016 Sameer. All rights reserved.
//

import WatchKit
import Foundation


class GlanceController: WKInterfaceController {

    @IBOutlet var dayLabelGl: WKInterfaceLabel!
    @IBOutlet var blockLabelGl: WKInterfaceLabel!
    
    let upperSchool = true
    
    var specialDay = false
    var havDay = false
    var winterDay = false
    var readingDay = false
    var avDay = false

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        //Figuring out the currentHour
        let date = NSDate()
        let calendar = NSCalendar.currentCalendar()
        let componentsHour = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Hour), fromDate: date)
        let componentsMinute = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Minute), fromDate: date)
        let componentsDay = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Day), fromDate: date)
        let componentsMonth = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Month), fromDate: date)
        let componentsYear = calendar.components(NSCalendarUnit.Year.union(NSCalendarUnit.Year), fromDate: date)
        let hour = componentsHour.hour
        let minute = componentsMinute.minute
        let day = componentsDay.day
        let month = componentsMonth.month
        let year = componentsYear.year
        //Return the message and block based on current hour and minute
        
        var dateAsString = "\(month)-\(day)-\(year)"
        var dayEnum = Days.day1
        
        if let plistPath = NSBundle.mainBundle().pathForResource("DaySchedule", ofType: "plist") {
            let dayScheduleDict = NSDictionary(contentsOfFile: plistPath)
            if let day = dayScheduleDict![dateAsString] as? String {
                //print
                (day)
                //var atrText = NSAttribute
                
                if dateAsString == "9-23-2016" {
                    avDay = true
                }
                
                switch day {
                case "Day 1":
                    dayEnum = Days.day1
                    //atrText = NSAttributedString(string: "Day 1", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 6)])
                    dayLabelGl.setText("DAY 1")
                    if !upperSchool {
                        let scheduleOfDay = DaySchedule(day: dayEnum)
                        findBlock(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 1")
                    }  else {
                        let scheduleOfDay = DayScheduleUS(day: dayEnum)
                        findBlockUS(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 2")
                    }
                case "Day 2":
                    dayEnum = Days.day2
                    //atrText = NSAttributedString(string: "Day 2", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 6)])
                    dayLabelGl.setText("DAY 2")
                    if !upperSchool {
                        let scheduleOfDay = DaySchedule(day: dayEnum)
                        findBlock(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 1")
                    }  else {
                        let scheduleOfDay = DayScheduleUS(day: dayEnum)
                        findBlockUS(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 2")
                    }
                case "Day 3":
                    dayEnum = Days.day3
                    //atrText = NSAttributedString(string: "Day 3", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 6)])
                    dayLabelGl.setText("DAY 3")
                    if !upperSchool {
                        let scheduleOfDay = DaySchedule(day: dayEnum)
                        findBlock(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 1")
                    }  else {
                        let scheduleOfDay = DayScheduleUS(day: dayEnum)
                        findBlockUS(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 2")
                    }
                case "Day 4":
                    dayEnum = Days.day4
                    //atrText = NSAttributedString(string: "Day 4", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 6)])
                    dayLabelGl.setText("DAY 4")
                    if !upperSchool {
                        let scheduleOfDay = DaySchedule(day: dayEnum)
                        findBlock(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 1")
                    }  else {
                        let scheduleOfDay = DayScheduleUS(day: dayEnum)
                        findBlockUS(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 2")
                    }
                case "Day 5":
                    
                    dayEnum = Days.day5
                    //atrText = NSAttributedString(string: "Day 5", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 6)])
                    dayLabelGl.setText("DAY 5")
                    if !upperSchool {
                        let scheduleOfDay = DaySchedule(day: dayEnum)
                        findBlock(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 1")
                    }  else {
                        let scheduleOfDay = DayScheduleUS(day: dayEnum)
                        findBlockUS(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 2")
                    }
                case "Day 6":
                    dayEnum = Days.day6
                    //atrText = NSAttributedString(string: "Day 6", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 6)])
                    dayLabelGl.setText("DAY 6")
                    if !upperSchool {
                        let scheduleOfDay = DaySchedule(day: dayEnum)
                        findBlock(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 1")
                    }  else {
                        let scheduleOfDay = DayScheduleUS(day: dayEnum)
                        findBlockUS(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 2")
                    }
                case "Day 7":
                    dayEnum = Days.day7
                    //atrText = NSAttributedString(string: "Day 7", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 6)])
                    dayLabelGl.setText("DAY 7")
                    if !upperSchool {
                        let scheduleOfDay = DaySchedule(day: dayEnum)
                        findBlock(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 1")
                    }  else {
                        let scheduleOfDay = DayScheduleUS(day: dayEnum)
                        findBlockUS(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 2")
                    }
                case "Day 8":
                    dayEnum = Days.day8
                    //atrText = NSAttributedString(string: "Day 8", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 6)])
                    dayLabelGl.setText("DAY 8")
                    if !upperSchool {
                        let scheduleOfDay = DaySchedule(day: dayEnum)
                        findBlock(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 1")
                    }  else {
                        let scheduleOfDay = DayScheduleUS(day: dayEnum)
                        findBlockUS(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 2")
                    }
                case "Day 9":
                    dayEnum = Days.day9
                    //atrText = NSAttributedString(string: "Day 9", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 6)])
                    dayLabelGl.setText("DAY 9")
                    if !upperSchool {
                        let scheduleOfDay = DaySchedule(day: dayEnum)
                        findBlock(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 1")
                    }  else {
                        let scheduleOfDay = DayScheduleUS(day: dayEnum)
                        findBlockUS(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 2")
                    }
                case "Day 10":
                    dayEnum = Days.day10
                    //atrText = NSAttributedString(string: "Day 10", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 6)])
                    dayLabelGl.setText("DAY 10")
                    if !upperSchool {
                        let scheduleOfDay = DaySchedule(day: dayEnum)
                        findBlock(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 1")
                    }  else {
                        let scheduleOfDay = DayScheduleUS(day: dayEnum)
                        findBlockUS(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 2")
                    }
                case "Day 11":
                    dayEnum = Days.day11
                    //atrText = NSAttributedString(string: "Day 11", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 6)])
                    dayLabelGl.setText("DAY 11")
                    if !upperSchool {
                        let scheduleOfDay = DaySchedule(day: dayEnum)
                        findBlock(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 1")
                    }  else {
                        let scheduleOfDay = DayScheduleUS(day: dayEnum)
                        findBlockUS(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 2")
                    }
                default:
                    dayEnum = Days.day12
                    //atrText = NSAttributedString(string: "Day 12", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(23, weight: 6)])
                    dayLabelGl.setText("DAY 12")
                    if !upperSchool {
                        let scheduleOfDay = DaySchedule(day: dayEnum)
                        findBlock(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 1")
                    }  else {
                        let scheduleOfDay = DayScheduleUS(day: dayEnum)
                        findBlockUS(scheduleOfDay, hour: hour, minute: minute)
                        print("ran 2")
                    }
                }
                
                if dateAsString == "10-19-2016" {
                    let atrText = NSAttributedString(string: "PSAT/Irr. Day", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(22, weight: 0)])
                    blockLabelGl.setAttributedText(atrText)
                    specialDay = true
                }
                
                if dateAsString == "11-11-2016" {
                    dayLabelGl.setText("EA DAY")
                    havDay = true
                    //findBlock adjust
                    let scheduleOfDay = DaySchedule(day: Days.eaHav)
                    findEAHAVBLock(scheduleOfDay, hour: hour, minute: minute)
                    //previous/next adjust
                }
                
                if dateAsString == "12-16-2016" {
                    winterDay = true
                    let scheduleOfDay = DaySchedule(day: Days.winterDay)
                    findWinterDay(scheduleOfDay, hour: hour, minute: minute)
                }
                
                let first = String(dateAsString[dateAsString.startIndex.advancedBy(0)])
                let dash = String(dateAsString[dateAsString.startIndex.advancedBy(1)])
                //print(dateAsString[index])
                if first == "1" && dash == "-" {
                    let second = String(dateAsString[dateAsString.startIndex.advancedBy(2)])
                    let integer = Int(second)
                    //print(integer)
                    if integer! >= 3 && integer! <= 13 {
                        if upperSchool {
                            print("JTERM")
                            blockLabelGl.setText("JTerm")
                            dayLabelGl.setText("JTerm")
                        }

                    } else {
                        var array: [Character] = []
                        for i in 2...3 {
                            let add = String(dateAsString[dateAsString.startIndex.advancedBy(i)])
                            array.append(Character(add))
                        }
                        let string = String(array)
                        if let integer = Int(string) {
                            if integer >= 3 && integer <= 13 {
                                if upperSchool {
                                    print("JTERM")
                                    blockLabelGl.setText("JTerm")
                                    dayLabelGl.setText("JTerm")
                                }
                            }
                        }
                    }
                }

                if dateAsString == "5-25-2017" {
                    if upperSchool {
                        let atrText = NSAttributedString(string: "Reading Day", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(20, weight: 0)])
                        dayLabelGl.setAttributedText(atrText)
                        dayLabelGl.setHorizontalAlignment(WKInterfaceObjectHorizontalAlignment.Center)
                        dayLabelGl.setVerticalAlignment(WKInterfaceObjectVerticalAlignment.Center)
                        blockLabelGl.setText("Reading Day")
                        readingDay = true
                    }
                }
                
                if dateAsString == "5-26-2017" {
                    if upperSchool {
                        dayLabelGl.setText("EXAMS")
                        blockLabelGl.setText("Final Exams")
                    } else {
                        let atrText = NSAttributedString(string: "No School", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(20, weight: 0.1)])
                        dayLabelGl.setAttributedText(atrText)
                        blockLabelGl.setText("N/A")
                    }
                }
                
                if dateAsString == "5-30-2017" || dateAsString == "5-31-2017" {
                    dayLabelGl.setText("EXAMS")
                    blockLabelGl.setText("Final Exams")
                }
                
                if dateAsString == "6-1-2017" {
                    dayLabelGl.setText("EXAMS")
                    blockLabelGl.setText("Final Exams")
                }
                
                if dateAsString == "6-2-2017" {
                    dayLabelGl.setText("Last Day")
                    let scheduleOfDay = DaySchedule(day: Days.lastDay)
                    findLastDay(scheduleOfDay, hour: hour, minute: minute)
                }
                
                //print("hello")
                
                //print("bye")
                
                //dayLabelGl.setAttributedText(atrText)
                
            } else {
                let atrText = NSAttributedString(string: "No School", attributes: [NSFontAttributeName: UIFont.systemFontOfSize(20, weight: 0.1)])
                dayLabelGl.setAttributedText(atrText)
                blockLabelGl.setText("N/A")
                
            }

        }

    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }
    
    func getTextForLabel(indexnumber: Int, dayschedule: DaySchedule) -> String {
        //print("\(dayschedule.schedule[indexnumber])")
        return dayschedule.schedule[indexnumber]
    }
    
    
    func getTextForLabelUS(indexnumber: Int, dayschedule: DayScheduleUS) -> String {
        //print("\(dayschedule.schedule[indexnumber])")
        return dayschedule.schedule[indexnumber]
    }
    
    func findBlock(scheduleOfDay: DaySchedule, hour: Int, minute: Int) {
        var indexTime = 1
        
        print(hour)
        print(minute)
        
        if hour < 8 || (hour == 8 && minute < 10){
            indexTime = 0
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if (hour == 8 && minute >= 10) && (hour == 8 && minute <= 50) {
            indexTime = 0
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 8 && minute > 50 {
            indexTime = 1
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if (hour == 9 && minute >= 0) && (hour == 9 && minute <= 35){
            indexTime = 1
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 9 && minute > 35 {
            indexTime = 2
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 && minute <= 20 {
            indexTime = 2
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 && minute > 20 {
            indexTime = 3
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if  hour == 11 && minute <= 5 {
            indexTime = 4
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if (hour == 11 && minute > 5) && (hour == 11 && minute <= 50) {
            indexTime = 5
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 11 && minute > 50 {
            indexTime = 5
            //messageLabel.setText("Activity:")
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 12 && minute < 30 {
            indexTime = 5
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 12 && minute >= 30 {
            indexTime = 6
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 13 && minute < 15 {
            indexTime = 6
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 13 && minute >= 15 {
            if !avDay {
                indexTime = 7
                blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
            } else {
                blockLabelGl.setText("Aurora Vesper Competitions")
            }
        }
        else if hour == 14 && minute >= 0 {
            if !avDay {
                indexTime = 8
                blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
            } else {
                blockLabelGl.setText("Aurora Vesper Competitions")
            }
        }
        else if hour > 14{
            if !avDay {
                indexTime = 8
                blockLabelGl.setText("It was \(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
            } else {
                blockLabelGl.setText("Aurora Vesper Competitions")
            }
        }
    }
    
    
    func findBlockUS(scheduleOfDay: DayScheduleUS, hour: Int, minute: Int) {
        var indexTime = 1
        
        print(hour)
        print(minute)
        
        if hour < 8 || (hour == 8 && minute < 10) {
            indexTime = 0
            blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if (hour == 8 && minute >= 10) && (hour == 8 && minute <= 50) {
            indexTime = 0
            blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 8 && minute > 50 {
            indexTime = 1
            blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if (hour == 9 && minute >= 0) && (hour == 9 && minute <= 35){
            indexTime = 1
            blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 9 && minute > 35 {
            indexTime = 2
            blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 && minute <= 10 {
            indexTime = 2
            blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 && minute > 10 {
            indexTime = 3
            blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if (hour == 11 && minute >= 0) && (hour == 11 && minute <= 50) {
            indexTime = 4
            blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 11 && minute > 50 {
            indexTime = 5
            blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 12 && minute <= 40 {
            indexTime = 5
            blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 12 && minute > 40 {
            indexTime = 6
            blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 13 && minute <= 15 {
            indexTime = 6
            blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 13 && minute > 15 {
            if !avDay {
                indexTime = 7
                blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
            } else {
                blockLabelGl.setText("Aurora Vesper Competitions")
            }
        }
        else if hour == 14 && minute >= 0 {
            if !avDay {
                indexTime = 8
                blockLabelGl.setText("It is \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
            } else {
                blockLabelGl.setText("Aurora Vesper Competitions")
            }
        }
        else if hour > 14 {
            if !avDay {
                indexTime = 8
                blockLabelGl.setText("It was \(getTextForLabelUS(indexTime, dayschedule: scheduleOfDay)) Block")
            } else {
                blockLabelGl.setText("Aurora Vesper Competitions")
            }
        }
    }
    
    func findEAHAVBLock(scheduleOfDay: DaySchedule, hour: Int, minute: Int) {
        var indexTime = 0
        
        if hour <= 8 {
            indexTime = 0
            blockLabelGl.setText("It is \(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 9 {
            indexTime = 1
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 {
            indexTime = 2
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 11 && minute >= 30 {
            indexTime = 3
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else {
            indexTime = 4
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
    }
    
    func findWinterDay(scheduleOfDay: DaySchedule, hour: Int, minute: Int) {
        var indexTime = 0
        
        if hour <= 8 {
            indexTime = 0
            //messageLabel.setText("First Class:")
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 8 && minute >= 10 {
            indexTime = 0
            //messageLabel.setText("First Class:")
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 8 && minute >= 50 {
            indexTime = 1
            //messageLabel.setText("Current Class:")
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 9 && minute >= 0 {
            indexTime = 1
            //messageLabel.setText("Current Class:")
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 9 && minute >= 45 {
            indexTime = 2
            //messageLabel.setText("Activity:")
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 10 && minute <= 20 {
            indexTime = 2
            //messageLabel.setText("Activity:")
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 10 && minute > 20 {
            indexTime = 3
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay)) Block")
        }
        else if hour == 10 && minute >= 55 {
            indexTime = 4
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else {
            indexTime = 4
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        
    }
    
    func findLastDay(scheduleOfDay: DaySchedule, hour: Int, minute: Int) {
        var indexTime = 0
        
        if hour < 10 {
            indexTime = 0
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 && minute <= 55 {
            indexTime = 1
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 10 && minute > 55 {
            indexTime = 2
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 11 {
            indexTime = 2
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 12 {
            indexTime = 3
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else if hour == 1 && minute <= 30 {
            indexTime = 3
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
        else {
            indexTime = 4
            blockLabelGl.setText("\(getTextForLabel(indexTime, dayschedule: scheduleOfDay))")
        }
    }


}


    

