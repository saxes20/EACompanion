//
//  EA_ScheduleTests.swift
//  EA_ScheduleTests
//
//  Created by Praneeth Alla on 12/14/15.
//  Copyright © 2015 Praneeth Alla. All rights reserved.
//

import XCTest
@testable import EA_Schedule

class EA_ScheduleTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }
    
    override func tearDown() {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        super.tearDown()
    }
    
    func testExample() {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
    }
    
    func testPerformanceExample() {
        // This is an example of a performance test case.
        self.measureBlock {
            // Put the code you want to measure the time of here.
        }
    }
    
}
