//
//  ViewController.swift
//  EA_Schedule
//
//  Created by Praneeth Alla on 12/14/15.
//  Copyright © 2015 Praneeth Alla. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet
    var tableView: UITableView!
    var objects = [[String: String]]()
    var enrollments = [[String: String]]()
    var classes: [String] = []
    var items: [String] = []
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.items.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell:UITableViewCell = self.tableView.dequeueReusableCellWithIdentifier("cell")! as UITableViewCell
        cell.textLabel?.text = self.items[indexPath.row]
        return cell
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let calendar = NSCalendar.currentCalendar()
        let tommorrow = calendar.dateByAddingUnit(.Day, value: 1, toDate: NSDate(), options: [])
        
        let date = NSDate();
        let formatter = NSDateFormatter();
        formatter.dateFormat = "yyyy-MM-dd";
        let dateFormatted = formatter.stringFromDate(date);
        let tommorrowFormatted = formatter.stringFromDate(tommorrow!)
        
        let defaults = NSUserDefaults.standardUserDefaults()
        let id = defaults.stringForKey("Login") as String!
        
        print("USERNAME: \(id)")
        
        if defaults.boolForKey("isStudent") as Bool! == false {
            let urlString = "https://api.ea:jqy2Pvg7hs@api.veracross.com/ea/v1/class_schedules.json?teachers=\(id)&date_from=\(dateFormatted)&date_to=\(tommorrowFormatted)"
        
            if let url = NSURL(string: urlString) {
                if let data = try? NSData(contentsOfURL: url, options: []) {
                    let json = JSON(data: data)
                    parseJSON(json)
                    //print(json);
                }
            }
        
            for var i = 0; i < objects.count; ++i {
                items.append(objects[i]["courseName"]!)
            }
        }
        
        if defaults.boolForKey("isStudent") as Bool! == true {
            let urlString = "https://api.veracross.com/ea/v1/enrollments.json?student=\(id)"
            
            if let url = NSURL(string: urlString) {
                if let data = try? NSData(contentsOfURL: url, options: []) {
                    let json = JSON(data: data)
                    parseStudentJSON(json)
                }
            }
            
            for var i = 0; i < classes.count; ++i {
                let urlString = "https://api.veracross.com/ea/v1/class_schedules.json?classes=\(classes[i])&date_from=\(dateFormatted)&date_to=\(dateFormatted)"
                
                if let url = NSURL(string: urlString) {
                    if let data = try? NSData(contentsOfURL: url, options: []) {
                        let json = JSON(data: data)
                        parseEnrollmentJSON(json)
                    }
                }
            }
            for var i = 0; i < enrollments.count; ++i {
                items.append(enrollments[i]["courseName"]!)
            }

        }
        
        self.tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    
    func parseJSON(json: JSON) {
        for result in json[].arrayValue{
            let courseName = result["categories"].stringValue
            let courseVersion = result["description"].stringValue
            let courseZipFile = result["location"].stringValue
            let obj = ["courseName": courseName, "courseVersion": courseVersion, "location": courseZipFile]
            objects.append(obj)
        }
        print(objects)
    }
    func parseStudentJSON(json: JSON) {
        for result in json[].arrayValue{
            let class_fk = result["class_fk"].stringValue
            classes.append(class_fk)
        }
    }
    func parseEnrollmentJSON(json: JSON) {
        for result in json[].arrayValue{
            let courseName = result["categories"].stringValue
            let courseVersion = result["description"].stringValue
            let courseZipFile = result["location"].stringValue
            let obj = ["courseName": courseName, "courseVersion": courseVersion, "location": courseZipFile]
            enrollments.append(obj)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

