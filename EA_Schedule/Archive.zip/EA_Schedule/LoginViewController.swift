//
//  LoginViewController.swift
//  EA_Schedule
//
//  Created by Praneeth Alla on 12/15/15.
//  Copyright © 2015 Praneeth Alla. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    var objects = [[String: String]]()
    var id = ""
    var student = false
    
    @IBOutlet weak var TextField: UITextField!
    
    @IBAction func LoginVerification(sender: AnyObject) {
        let defaults = NSUserDefaults.standardUserDefaults()
        
        if TextField.text!.characters.last! == "9"  {
            student = true
        }
        else if TextField.text!.characters.last! == "8" {
            student = true
        }
        else if TextField.text!.characters.last! == "7" {
            student = true
        }
        else if TextField.text!.characters.last! == "6" {
            student = true
        }
        else if TextField.text!.characters.last! == "5" {
            student = true
        }
        else if TextField.text!.characters.last! == "4" {
            student = true
        }
        else if TextField.text!.characters.last! == "3" {
            student = true
        }
        else if TextField.text!.characters.last! == "2" {
            student = true
        }
        else if TextField.text!.characters.last! == "1" {
            student = true
        }
        else if TextField.text!.characters.last! == "0" {
            student = true
        }
        else {
            student = false
        }
        
        if !student {
            let urlString = "https://api.ea:jqy2Pvg7hs@api.veracross.com/ea/v1/facstaff.json"
            
            if let url = NSURL(string: urlString) {
                if let data = try? NSData(contentsOfURL: url, options: []) {
                    let json = JSON(data: data)
                    parseJSON(json);
                }
            }
        }
        if student {
            let urlString = "https://api.ea:jqy2Pvg7hs@api.veracross.com/ea/v1/students.json"
            
            if let url = NSURL(string: urlString) {
                if let data = try? NSData(contentsOfURL: url, options: []) {
                    let json = JSON(data: data)
                    parseJSON(json);
                }
            }
        }
        
        for var i = 0; i < objects.count; ++i {
            if objects[i]["username"] == TextField.text {
                id = objects[i]["person_pk"]!
            }
        }

        defaults.setValue(id, forKey: "Login")
        defaults.setValue(student, forKey: "isStudent")
        
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let resultViewController = storyBoard.instantiateViewControllerWithIdentifier("ScheduleView") as! ViewController
        self.presentViewController(resultViewController, animated:true, completion:nil)
    }
    
    func parseJSON(json: JSON) {
        for result in json[].arrayValue{
            let person_pk = result["person_pk"].stringValue
            let username = result["username"].stringValue
            let obj = ["person_pk": person_pk, "username": username]
            objects.append(obj)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
